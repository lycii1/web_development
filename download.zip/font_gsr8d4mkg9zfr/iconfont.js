;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-instagram" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M544.059897 959.266898h-64.949141c-228.633593 0-415.697442-187.063849-415.697442-415.697442v-64.949141c0-228.633593 187.063849-415.697442 415.697442-415.697442h64.949141c228.633593 0 415.697442 187.063849 415.697442 415.697442v64.949141C959.756315 772.203049 772.692466 959.266898 544.059897 959.266898z" fill="#181818" ></path>' +
    '' +
    '<path d="M509.715712 393.059337c-65.754939 0-119.059433 53.304494-119.059434 119.059434s53.304494 119.059433 119.059434 119.059433 119.059433-53.304494 119.059433-119.059433S575.470651 393.059337 509.715712 393.059337zM509.715712 589.593102c-42.787144 0-77.474331-34.686163-77.474331-77.474331s34.686163-77.474331 77.474331-77.474331 77.474331 34.686163 77.474331 77.474331S552.50388 589.593102 509.715712 589.593102zM740.495369 411.102245c0-72.572992-57.189115-129.762107-129.762107-129.762107 0 0-51.329419-1.642312-101.016526-1.642312s-99.374214 1.642312-99.374214 1.642312c-72.572992 0-131.405443 58.832451-131.405443 131.405442 0 0-1.642312 46.455725-1.642312 94.447278 0 51.274129 1.642312 104.302174 1.642312 104.302175 0 72.572992 58.832451 131.405443 131.405443 131.405442 0 0 46.455725 1.642312 94.447278 1.642312 51.274129 0 105.944486-1.642312 105.944486-1.642312 72.572992 0 129.762107-57.189115 129.762106-129.762106 0 0 1.642312-52.43112 1.642312-102.659863C742.137681 461.34225 740.495369 411.102245 740.495369 411.102245zM698.955317 605.10394c0 59.510263-36.743149 96.253412-96.253412 96.253412 0 0-54.980594 1.347433-97.025421 1.347433-39.353032 0-87.302606-1.347433-87.302606-1.347433-59.509239 0-97.895724-38.387509-97.895724-97.895724 0 0-1.347433-53.338282-1.347433-95.383109 0-39.353032 1.347433-88.944918 1.347433-88.944918 0-59.510263 38.387509-96.253412 97.895724-96.253412 0 0 50.598365-1.347433 91.342858-1.347433 40.744493 0 92.98517 1.347433 92.985169 1.347433 59.510263 0 96.253412 36.743149 96.253412 96.253412 0 0 1.347433 51.348873 1.347433 91.637737C700.301726 551.959173 698.955317 605.10394 698.955317 605.10394zM634.472043 360.019582c-15.887629 0-28.768106 12.943958-28.768106 28.910426 0 15.966468 12.880477 28.909402 28.768106 28.909402 15.887629 0 28.767082-12.942934 28.767082-28.909402C663.239125 372.962516 650.359672 360.019582 634.472043 360.019582z" fill="#FFFFFF" ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)